# quadro-acidente
Quadro de acidentes em obras / empresas desenvolvido em python, framework Django.

Utiliza-se a logo da comissão interna de prevenção de acidentes no app, pois normalmente a cipa trata desse tipo de assunto
