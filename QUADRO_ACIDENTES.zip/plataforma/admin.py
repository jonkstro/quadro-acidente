from django.contrib import admin

from .models import Acidente

# Register your models here.
admin.site.register(Acidente)