<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
function cadastrar() {
    <script>
        Swal.fire(
              '',
              'Cadastrado Acidente!',
              'success'
            )
    </script>
}
